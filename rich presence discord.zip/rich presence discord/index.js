var rpc = require("discord-rpc")
// By zwk.
rpc = require("discord-rpc")
const client = new rpc.Client({ transport: 'ipc' })
client.on('ready', () => {
client.request('SET_ACTIVITY', {
pid: process.pid,

activity : {
// 2nd line of the RP (Minimum 2 characters)
details : "01100001",

assets : {
// Large image with non-clickable text (lowercase only)
large_image : "the picture link",
large_text : "words above the picture",


// RP button(s): Maximum 2 - Minimum 0
// (You can't click your own buttons)
},
buttons : [
// Button n'1 | (Add // in front to disable them: "// {label: [...]" )
{label : "button 1" , url : "link button 1"},
// Button n'2 | (Add // in front to disable them: "// {label: [...]" )
{label : "button 2 name",url : "link button 2"}
]
}
})
})

// ClientID to retrieve from: https://discord.com/developers/applications/ (Applications ID)
// The name of your application will correspond to the first line of the RP (In bold)
client.login({ clientId : "the id of your bot" }).catch(console.error);

// Glory to Zwk